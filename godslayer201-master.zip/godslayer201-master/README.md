### Hello World 👋 It's [Rachitt!](https://godslayer201.github.io/)

<p align="center">
  <img src="https://github.com/yashagrawal300/yashagrawal300/blob/master/github.gif" width=100>
  <br>

[![Linkedin Badge](https://img.shields.io/badge/-Rachitt_Shah-blue?style=flat&logo=Linkedin&logoColor=white&link=https://www.linkedin.com/in/rachitt-shah/)](https://www.linkedin.com/in/rachitt-shah)
[![Website Badge](https://img.shields.io/badge/-godslayer201.github.io-47CCCC?style=flat&logo=Google-Chrome&logoColor=white&link=https:https://godslayer201.github.io/)](https://godslayer201.github.io/)
[![Twitter Badge](https://img.shields.io/badge/-@rachittshah20-1ca0f1?style=flat&labelColor=1ca0f1&logo=twitter&logoColor=white&link=https://mobile.twitter.com/rachittshah)](https://mobile.twitter.com/rachittshah)
[![Instagram Badge](https://img.shields.io/badge/-@rachitt__shah-purple?style=flat&logo=instagram&logoColor=white&link=https:https://www.instagram.com/rachitt_shah/)](https://www.instagram.com/rachitt_shah/)
[![Gmail Badge](https://img.shields.io/badge/-rachitt01-c14438?style=flat&logo=Gmail&logoColor=white&link=mailto:rachitt01@gmail.com)](mailto:rachitt01@gmail.com)
<br>



Hi,I'm Rachitt Shah <img align="center" src="https://media.giphy.com/media/1fhj2FW0661V3Nb2Me/giphy.gif" width="50"> ! I'm interested in web development,cross platform development and Dev-Ops,and I'm active in competitive programming too. Glad that you visited my profile!



<img align="right" alt="GIF" src="https://media.giphy.com/media/USV0ym3bVWQJJmNu3N/giphy.gif" />


**About me:**


- 🌱 I’m active in [Competitive Coding!](https://www.codechef.com/users/rachitt_shah20)
- 👯 Curious about everything,hit me up!
- 📫 How to reach me: Any of the Social-Media Platforms.
- 👯 Part of the Management team [@dscvitpune](https://github.com/dscvitpune)
- ✨ I'm into gaming,poetry and a cinema aficionado.
-  🔭 **I’m currently working on**
![](https://img.shields.io/badge/Python-%7C-0%2C%2022%2C%20100)  ![](https://img.shields.io/badge/Web%20Development-%7C-red)    ![](https://img.shields.io/badge/C++-%7C-yellowgreen)   ![Open Source Love](https://badges.frapsoft.com/os/v1/open-source.svg?v=103)

<b>You can site my portfolio:<b> https://godslayer201.github.io/

 




 
### Languages and Tools :


<code><img height="30" src="https://raw.githubusercontent.com/github/explore/80688e429a7d4ef2fca1e82350fe8e3517d3494d/topics/python/python.png"></code>
<code><img height="30" src="https://raw.githubusercontent.com/github/explore/80688e429a7d4ef2fca1e82350fe8e3517d3494d/topics/javascript/javascript.png"></code>
<code><img height="30" src="https://raw.githubusercontent.com/github/explore/80688e429a7d4ef2fca1e82350fe8e3517d3494d/topics/html/html.png"></code>
<code><img height="30" src="https://raw.githubusercontent.com/github/explore/80688e429a7d4ef2fca1e82350fe8e3517d3494d/topics/css/css.png"></code>
<code><img height="30" src="https://raw.githubusercontent.com/github/explore/80688e429a7d4ef2fca1e82350fe8e3517d3494d/topics/react/react.png"></code>
<code><img height="30" src="https://raw.githubusercontent.com/github/explore/80688e429a7d4ef2fca1e82350fe8e3517d3494d/topics/aws/aws.png"></code>
<code><img height="30" src="https://raw.githubusercontent.com/github/explore/80688e429a7d4ef2fca1e82350fe8e3517d3494d/topics/cpp/cpp.png"></code>
<code><img height="30" src="https://raw.githubusercontent.com/github/explore/80688e429a7d4ef2fca1e82350fe8e3517d3494d/topics/git/git.png"></code>
<code><img height="30" src="https://raw.githubusercontent.com/github/explore/80688e429a7d4ef2fca1e82350fe8e3517d3494d/topics/nodejs/nodejs.png"></code>
<code><img height="30" src="https://raw.githubusercontent.com/github/explore/80688e429a7d4ef2fca1e82350fe8e3517d3494d/topics/terminal/terminal.png"></code>

<br>
<br>

### Areas Of Work:

<code><img height="50" src="https://image.flaticon.com/icons/svg/2535/2535543.svg"></code>
<code><img height="50" src="https://image.flaticon.com/icons/svg/1596/1596639.svg"></code>
<code><img height="50" src="https://image.flaticon.com/icons/svg/944/944179.svg"></code>
<code><img height="50" src="https://image.flaticon.com/icons/svg/2942/2942156.svg"></code>
<code><img height="50" src="https://image.flaticon.com/icons/svg/2235/2235061.svg"></code>
<code><img height="50" src="https://image.flaticon.com/icons/svg/3003/3003696.svg"></code>
<code><img height="50" src="https://image.flaticon.com/icons/svg/2885/2885535.svg"></code>
<code><img height="50" src="https://image.flaticon.com/icons/svg/3056/3056301.svg"></code>
<code><img height="50" src="https://image.flaticon.com/icons/svg/1680/1680899.svg"></code>
<code><img height="50" src="https://image.flaticon.com/icons/svg/3118/3118399.svg"></code>
<code><img height="50" src="https://cdn.icon-icons.com/icons2/1508/PNG/512/matlab_104289.png"></code>
<code><img height="50" src="https://image.flaticon.com/icons/svg/1628/1628182.svg"></code>
<code><img height="50" src="https://image.flaticon.com/icons/png/512/2085/2085061.png"></code>




**Stats :**  (https://gitstats.me/godslayer201)
<br>

<i>Note :</i>  These are not an indication of my skill level, just an overview of commits.

[![Rachitt's github stats](https://github-readme-stats.vercel.app/api?username=godslayer201)](https://github.com/godlsayer201/github-readme-stats)


<u><i><b> Feel free to fork this repo and apply this template for your own Github profile.Cheers!</i></b></u>








